Conversion of Servlet based Starbucks 
Using Model 2 Servlet/JSPs "pairs"
 
