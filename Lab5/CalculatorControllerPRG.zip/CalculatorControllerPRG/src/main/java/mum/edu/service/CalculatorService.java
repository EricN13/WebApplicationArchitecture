package mum.edu.service;

import mum.edu.domain.Calculator;

public interface CalculatorService {

	
	public void add(Calculator calculator);
	
	public void mult(Calculator calculator);

}
