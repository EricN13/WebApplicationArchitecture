The solution to the problem Lab8_valid

Looks a lot like  Exam2For315