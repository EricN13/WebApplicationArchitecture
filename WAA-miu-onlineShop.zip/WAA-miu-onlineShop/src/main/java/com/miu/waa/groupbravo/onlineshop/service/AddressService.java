package com.miu.waa.groupbravo.onlineshop.service;

import com.miu.waa.groupbravo.onlineshop.domain.Address;

public interface AddressService {
    public void save(Address address);
}
