package com.miu.waa.groupbravo.onlineshop.service.message;

public interface ServiceMessage {
    public static int USER_MESSAGE_ERROR=1001;
    public static int USER_MESSAGE_ERROR_WHILE_SAVING=1002;

}
